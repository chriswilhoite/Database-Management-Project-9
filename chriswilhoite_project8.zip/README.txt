Name: Chris Wilhoite
Challenged encountered: I had difficulty running the schema.sql against the database initially. Then I had issues figuring out the correct way to modify the database
using "self.db.commit()".
Like/Dislike: I liked learning how to implement SQL into python. I disliked spending a bunch of time trying to figure out connections to the db and psql syntax.
Time spent: I spent 8-10 hrs (would have been WAY LESS if it wasn't for the challeneges stated before)